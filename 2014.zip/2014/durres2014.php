	<?php include '/menus/mainHeader.html'?>
    <link href="../styles/style.css" rel="stylesheet" type="text/css" media="screen" />
    <title>DURRES | BALKAN ATHLETICS OFFICIAL WEBSITE</title>
</head>

<body>
	<!--START HEAD WRAPPER-->
	<div id="head_wrapper">
    
    </div>
    

	<!--END HEAD WRAPPER-->
    
	<!--START MAIN WRAPPER -->
    <div id="main_wrapper">
    	
        
        
        <!--START HEADER-->     	
        <?php include'/menus/header.html'?>
 	
    	<?php include'/menus/mainMenu.html'?>

      
        </div>
        <!--END HEADER-->
        
        <!--START PAGE WRAPPER-->
        <div id="page_wrapper">
            
            <?php include'/menus/leftSidebar.html'?>
            <!--START CONTENT WRAPPER -->
            <div id="content">
            	<div class="content_wrapper">
                	<p class="content_smallTitle">6 APRIL 2014 - BALKAN HALF MARATHON CHAMPIONSHIPS<br>DURRES</p>
                    <hr width="40%" color="#0DB10F" size="1px"><br>
               		<div class="newsMain">
                    	<p>Results Men: <a href="pdf/Results Men BHMC 2014 Durres ALB.pdf" target="_blank">CLICK HERE</a></p>
        				<p>Results Women: <a href="pdf/Results Women BHMC 2014 Durres ALB.pdf" target="_blank">CLICK HERE</a></p>
                    </div>
                </div>
                <!--END CONTENT WRAPPER-->
                    
                
            </div>
            <!--END CONTENT WRAPPER-->
            
            <?php include'/menus/rightSidebar.html'?>
            
            
            
        </div>
        <!--END PAGE WRAPPER-->
        
       	<?php include'/menus/mainFooter.html'?>
        
	</div>
    <!-- END MAIN WRAPPER-->




</body>
</html>
